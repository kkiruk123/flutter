import 'package:flutter/material.dart';

class cartPage extends StatelessWidget {
  @override
  Widget build(BuildContext) {
    return Scaffold(
        appBar: AppBar(
      title: Text('Shopping Cart'),
    ));
  }
}
